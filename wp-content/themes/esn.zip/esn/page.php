<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package esn
 */

get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
    <div class="page_title1">
        <div class="container">

            <h1><?php the_title(); ?></h1>

        </div>
    </div><!-- end page title -->

    <div class="content_fullwidth">

        <div class="container">
            <?php the_content(); ?>
        </div>
        <!-- end all sections -->


        <!-- end featured section 46 -->


    </div>
<?php endwhile; // End of the loop. ?>
<?php //get_sidebar(); ?>
<?php get_footer(); ?>
