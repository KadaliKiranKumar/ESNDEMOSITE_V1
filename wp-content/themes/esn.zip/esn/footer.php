<footer class="footer">
    <div class="container">

        <div class="one_fourth animate" data-anim-type="fadeInUp" data-anim-delay="100">
            <ul class="faddress">

                <li><i class="fa fa-map-marker fa-lg"></i>&nbsp; ESN Technologies</li>
                <li>floor, 8-2-248/A
                </li>
                <li>Maharishi House</li>
                <li> Road No #3, Banjara Hills </li>
                <li>Hyderabad 500 034</li>
                <li><i class="fa fa-phone"></i>&nbsp;  91-40-23351944/45</li>
                <li><i class="fa fa-print"></i>&nbsp; 91-40-23351942</li>
                <li><a href="mailto:info@esntechnologies.co.in"><i class="fa fa-envelope"></i>&nbsp; info@esntechnologies.co.in</a>
                </li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/images/footer-wmap.png" alt=""/></li>
            </ul>
        </div>
        <!-- end address -->

        <div class="one_fourth animate" data-anim-type="fadeInUp" data-anim-delay="200">
            <div class="qlinks">

                <h4>Useful Links</h4>

                <ul>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Home Page Variations</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Awsome Slidershows</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Features and Typography</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Different &amp; Unique Pages</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Single and Portfolios</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Recent Blogs or News</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i> Layered PSD Files</a></li>
                </ul>

            </div>
        </div>
        <!-- end links -->

        <div class="one_fourth animate" data-anim-type="fadeInUp" data-anim-delay="300">
            <div class="siteinfo">

                <h4>Twitter Feeds</h4>

                <ul class="twitter_feeds_three">

                    <li class="bhline"><i class="fa fa-twitter fa-lg"></i> <a href="https://twitter.com/gsrthemes9"
                                                                              target="_blank">gsrthemes9</a>: Hoxa -
                        Responsive html5 Professional Theme
                        <em>.9 days ago &nbsp;.<a href="#">reply</a> &nbsp;.<a href="#">retweet</a> &nbsp;.<a href="#">favorite</a></em>
                    </li>

                    <li><i class="fa fa-twitter fa-lg"></i> <a href="https://twitter.com/gsrthemes9" target="_blank">gsrthemes9</a>:
                        elos - Responsive HTML5 / CSS3, Simple, Clean and Professional Multipurpose Use.
                        <em>.12 days ago &nbsp;.<a href="#">reply</a> &nbsp;.<a href="#">retweet</a> &nbsp;.<a href="#">favorite</a></em>
                    </li>

                </ul>

            </div>
        </div>
        <!-- end site info -->

        <div class="one_fourth last animate" data-anim-type="fadeInUp" data-anim-delay="400">

            <h4>Flickr Photos</h4>

            <div id="flickr_badge_wrapper">

                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>
                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>
                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>
                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>
                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>
                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>
                <a href="#" target="_blank"><img src="http://placehold.it/70x70" alt=""></a>

            </div>

        </div>
        <!-- end flickr -->

    </div>
    <!-- end footer -->

    <div class="clearfix"></div>

    <div class="copyright_info">
        <div class="container">

            <div class="clearfix divider_dashed10"></div>

            <div class="one_half animate" data-anim-type="fadeInRight" data-anim-delay="300">

                Copyright � 2015 LinStar.com. All rights reserved. <a href="#">Terms of Use</a> | <a href="#">Privacy
                    Policy</a>

            </div>

            <div class="one_half last">

                <ul class="footer_social_links">
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-facebook"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-twitter"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-google-plus"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-linkedin"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-skype"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-flickr"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-html5"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-youtube"></i></a></li>
                    <li class="animate" data-anim-type="zoomIn" data-anim-delay="300"><a href="#"><i
                                class="fa fa-rss"></i></a></li>
                </ul>

            </div>

        </div>
    </div>
    <!-- end copyright info -->


</footer>


<a href="#" class="scrollup">Scroll</a><!-- end scroll to top of the page-->


</div>


<!-- ######### JS FILES ######### -->
<!-- get jQuery used for the theme -->
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/universal/jquery.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/style-switcher/styleselector.js"></script>
<script
    src="<?php echo get_template_directory_uri(); ?>/js/animations/js/animations.min.js"
    type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/mainmenu/bootstrap.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/mainmenu/customeUI.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/scrolltotop/totop.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/mainmenu/sticky.js"></script>
<script type="text/javascript"
        src="<?php echo get_template_directory_uri(); ?>/js/mainmenu/modernizr.custom.75180.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/carouselowl/owl.carousel.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/universal/custom.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/masterslider/masterslider.min.js"></script>
<script type="text/javascript">
    (function ($) {
        "use strict";
        var slider = new MasterSlider();
        // adds Arrows navigation control to the slider.
        slider.control('arrows');
        slider.control('bullets');

        slider.setup('masterslider', {
            width: 1400, // slider standard width
            height: 380, // slider standard height
            space: 0,
            speed: 45,
            layout: 'fullwidth',
            loop: true,
            preload: 0,
            autoplay: true,
            view: "parallaxMask"
        });
    })(jQuery);
</script>
<?php wp_footer(); ?>

</body>
</html>
