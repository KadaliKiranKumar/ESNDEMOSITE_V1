<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package esn
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/images/favicon.png"/>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">

    <!-- this styles only adds some repairs on idevices  -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Google fonts - witch you want to use - (rest you can just remove) -->
    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic'
        rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet'
          type='text/css'>
    <link
        href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic'
        rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Dancing+Script:400,700' rel='stylesheet' type='text/css'>


    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- ######### CSS STYLES ######### -->

    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/reset.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css" type="text/css"/>

    <!-- font awesome icons -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/font-awesome//css/font-awesome.min.css">

    <!-- simple line icons -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/simpleline-icons/simple-line-icons.css" media="screen"/>

    <!-- et linefont icons -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/et-linefont/etlinefont.css">

    <!-- animations -->
    <link href="<?php echo get_template_directory_uri(); ?>/js/animations/css/animations.min.css" rel="stylesheet" type="text/css" media="all"/>

    <!-- responsive devices styles -->
    <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri(); ?>/css/responsive-leyouts.css" type="text/css"/>

    <!-- shortcodes -->
    <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri(); ?>/css/shortcodes.css" type="text/css"/>


    <!-- mega menu -->
    <link href="<?php echo get_template_directory_uri(); ?>/js/mainmenu/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/js/mainmenu/demo.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/js/mainmenu/menu.css" rel="stylesheet">

    <!-- owl carousel -->
    <link href="<?php echo get_template_directory_uri(); ?>/js/carouselowl/owl.transitions.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/js/carouselowl/owl.carousel.css" rel="stylesheet">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div class="site_wrapper">

    <header class="header innerpages">

        <div class="container">

            <!-- Logo -->
            <div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" id="logo"></a></div>

            <!-- Navigation Menu -->
            <div class="menu_main">

                <div class="navbar yamm navbar-default">

                    <div class="navbar-header">
                        <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse"
                             data-target="#navbar-collapse-1"><span>Menu</span>
                            <button type="button"><i class="fa fa-bars"></i></button>
                        </div>
                    </div>

                    <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">

                        <nav>

<!--                            <ul class="nav navbar-nav">-->
                                <?php wp_nav_menu( array('menu'=>'main','container'=>'','menu_class'=>'nav navbar-nav') ); ?>
<!--                                <li class=""><a href="--><?php //echo esc_url( home_url( '/' ) ); ?><!--" class="">Home</a>-->
<!--                                </li>-->
<!---->
<!--                                <li class=""><a href="#" data-toggle="dropdown" class="">Pages</a>-->
<!--                                </li>-->
<!---->
<!--                                <li class=""><a href="#" >Features</a>-->
<!---->
<!--                                </li>-->
<!---->
<!--                                <li class=""><a href="#" data-toggle="" class="">Portfolio</a>-->
<!--                                </li>-->
<!---->
<!--                                <li class=" "><a href="#" data-toggle="" class="">Shortcodes</a>-->
<!---->
<!--                                </li>-->



<!--                            </ul>-->

                        </nav>

                    </div>

                </div>
            </div>
            <!-- end Navigation Menu -->


        </div>

    </header>