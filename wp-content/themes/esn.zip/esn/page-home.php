<?php
/**
 *
 * Template Name: Home page
 */

get_header(); ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/js/masterslider/style/masterslider.css" />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/js/masterslider/skins/default/style.css" />
<div class="slidermar">
    <div class="master-slider ms-skin-default" id="masterslider">

        <div class="ms-slide slide-1" data-delay="9">

            <div class="slide-pattern"></div>

            <img src="<?php echo get_template_directory_uri(); ?>/js/masterslider/blank.gif" data-src="http://www.esntechnologies.com/images/slider/home/header3.jpg" alt=""/>

        </div>
        <!-- end slide 1 -->


        <div class="ms-slide slide-2" data-delay="9">

            <div class="slide-pattern"></div>

            <img src="<?php echo get_template_directory_uri(); ?>/js/masterslider/blank.gif" data-src="http://www.esntechnologies.com/images/slider/home/header2.jpg" alt=""/>

        </div>
        <!-- end slide 2 -->


        <div class="ms-slide slide-3" data-delay="9">

            <div class="slide-pattern"></div>

            <img src="<?php echo get_template_directory_uri(); ?>/js/masterslider/blank.gif" data-src="http://www.esntechnologies.com/images/slider/home/header1.jpg" alt=""/>

        </div>
        <!-- end slide 3 -->

    </div>
</div>
<?php while (have_posts()) : the_post(); ?>
    <div class="clearfix divider_line margin_top10 margin_bottom10"></div>

    <div class="featured_section2">
        <div class="container">

            <div class="one_fourth_less animate" data-anim-type="fadeIn" data-anim-delay="300">

                <img src="http://placehold.it/275x220" alt="" class="rimg"/> <h4>Staffing and Consulting</h4>

                <p>Our Global Resourcing Strategy brings the best talent. ESN and teams are tailored to suit all your IT
                    needs.</p>
                <a href="#" class="button two">Read More</a>

            </div>
            <!-- end section -->

            <div class="one_fourth_less animate" data-anim-type="fadeIn" data-anim-delay="400">

                <img src="http://placehold.it/275x220" alt="" class="rimg"/> <h4>Application Development</h4>

                <p>Our outsourcing services enable enterprise to develop software faster, maintain applications at lower
                    costs, re-engineer and..</p>
                <a href="#" class="button two">Read More</a>

            </div>
            <!-- end section -->

            <div class="one_fourth_less active animate" data-anim-type="fadeIn" data-anim-delay="500">

                <img src="http://placehold.it/275x220" alt="" class="rimg"/> <h4>Embedded Engineering</h4>

                <p>We provide end-to-end services to customers in markets that include Network and Telecom, Wireless,
                    Consumer Electronics, Media</p>
                <a href="#" class="button two">Read More</a>

            </div>
            <!-- end section -->

            <div class="one_fourth_less last animate" data-anim-type="fadeIn" data-anim-delay="600">

                <img src="http://placehold.it/275x220" alt="" class="rimg"/> <h4>Testing and QA</h4>

                <p>To ensure a solid return on your IT investments, ESN offers QA, Verification, Validation and Testing
                    services throughout the software</p>
                <a href="#" class="button two">Read More</a>

            </div>
            <!-- end section -->

        </div>
    </div>
    <div class="content_fullwidth">

        <div class="container">
            <?php the_content(); ?>
        </div>
        <!-- end all sections -->


        <!-- end featured section 46 -->


    </div>
<?php endwhile; // End of the loop. ?>
<?php //get_sidebar(); ?>
<?php get_footer(); ?>
